# 🎮✨ Séjour Magique Entre Amies

Une app web privée et ludique pour organiser un séjour entre copines !

## 🎯 Fonctionnalités

- **📅 Planning** : Activités du séjour, horaires, lieux, repas
- **🎲 Jeux & Défis** : Défi aléatoire du jour + Loto des corvées
- **🍽️ Repas & Courses** : Menus et liste de courses éditable en temps réel
- **📸 Galerie & Médias** : Upload photos + Playlist Deezer intégrée
- **🎁 Surprises** : Codes secrets déverrouillant vidéos/audios surprises

## 🎨 Design

- Interface **old-school game** avec emojis ludiques
- Palette **pastel bleu/rose/violet**
- Navigation par **5 onglets en bas** (mobile-first)
- Responsive et ultra-simple d'utilisation

## 🚀 Tech Stack

- **Frontend** : React 18 + Vite + Tailwind CSS
- **Backend** : Supabase (PostgreSQL + Storage)
- **Deploy** : Netlify
- **Version Control** : GitHub

## 📋 Installation rapide

```bash
# 1. Cloner
git clone https://github.com/TON_USERNAME/sejour-entre-amies.git
cd sejour-entre-amies

# 2. Installer les dépendances
npm install

# 3. Ajouter tes variables d'env (.env.local)
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=ton-key

# 4. Lancer localement
npm run dev

# 5. Build pour la prod
npm run build
```

## 🔐 Authentification

Code par défaut : `2024AMIES` (à changer dans `src/App.jsx`)

## 📝 Guide complet

Voir `SETUP_GUIDE.md` pour les instructions détaillées (Supabase + GitHub + Netlify)

## 👩‍💻 Customisation

- **Ajouter des amies** : Mettre à jour les noms dans les listes
- **Ajouter des activités** : Modifier la data dans l'état React (ou Supabase)
- **Uploader des photos** : Utiliser Supabase Storage
- **Ajouter une playlist** : Remplacer le lien Deezer dans `GalleryTab`
- **Vidéos surprises** : Uploader sur Supabase Storage et utiliser les codes secrets

## 🎉 Prêt à s'amuser ?

L'app est ready-to-go. Customise, partage le lien avec les amies, et que la magie commence ! ✨

---

*Made with 💙💗 for girl trips*
