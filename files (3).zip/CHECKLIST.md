# ✅ Checklist Démarrage Rapide - Séjour Magique

## 📦 Fichiers générés

Voici tous les fichiers que j'ai créés. Tu vas les copier dans ton repo GitHub :

```
sejour-entre-amies/
├── src/
│   ├── App.jsx                (✅ App principale - 300+ lignes)
│   ├── main.jsx               (✅ Point d'entrée React)
│   └── index.css              (✅ Styles Tailwind)
├── index.html                 (✅ HTML principal)
├── package.json               (✅ Dépendances)
├── vite.config.js            (✅ Config Vite)
├── tailwind.config.js        (✅ Config Tailwind)
├── postcss.config.js         (✅ Config PostCSS)
├── .env.example              (✅ Template env vars)
├── .gitignore                (✅ Fichiers à ignorer)
├── README.md                 (✅ Documentation)
├── SETUP_GUIDE.md            (✅ Guide détaillé)
└── CHECKLIST.md              (✅ Ce fichier)
```

---

## 🚀 Étapes à suivre (15 min max)

### **1️⃣ SUPABASE (2 min)**
- [ ] Aller sur supabase.com et créer un projet gratuit
- [ ] Copier le code SQL du `SETUP_GUIDE.md` dans SQL Editor
- [ ] Noter ton **Project URL** et **Anon Key**

### **2️⃣ GITHUB (3 min)**
- [ ] Créer un repo public `sejour-entre-amies`
- [ ] Cloner localement et entrer dans le dossier
- [ ] Copier TOUS les fichiers de ce projet dedans

### **3️⃣ SETUP LOCAL (5 min)**
```bash
# Se placer dans ton repo
cd sejour-entre-amies

# Installer les dépendances
npm install

# Créer .env.local avec tes credentials Supabase
cat > .env.local << 'EOF'
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...
EOF

# Tester localement
npm run dev
```

Test: Code `2024AMIES` pour login

### **4️⃣ GITHUB PUSH (2 min)**
```bash
git add .
git commit -m "Initial commit: Séjour Magique app"
git push origin main
```

### **5️⃣ NETLIFY DEPLOY (3 min)**
- [ ] Aller sur netlify.com
- [ ] Cliquer "Connect with GitHub"
- [ ] Sélectionner ton repo `sejour-entre-amies`
- [ ] Build command: `npm run build`
- [ ] Publish directory: `dist`
- [ ] Ajouter variables d'env (VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY)
- [ ] Cliquer "Deploy"
- [ ] Attendre 2-3 min... ✅ **C'est live !**

---

## 📖 Pour plus de détails

Consulte **SETUP_GUIDE.md** pour :
- Instructions Supabase détaillées (SQL)
- Configuration GitHub
- Configuration Netlify
- Customisation de l'app

---

## 🎮 Prêt à customiser ?

Une fois en ligne, tu peux :

### Changer le code d'accès
Dans `src/App.jsx`, ligne 37 :
```javascript
const CORRECT_CODE = '2024AMIES'; // ← Change ici
```

### Ajouter des amies
Dans `src/App.jsx`, cherche `friends` et `const friends = [...]`

### Ajouter des activités
Modifie les listes `activities` et `challenges` dans le code

### Uploader des vraies photos
- Créer un bucket Storage dans Supabase
- Uploader des images
- Les afficher dans la galerie

### Ajouter ta playlist Deezer
L'iframe est déjà là (ligne ~550 environ). Remplace juste l'ID de playlist.

### Ajouter des vidéos surprises
- Uploader une vidéo sur Supabase Storage
- L'intégrer dans le tab `SurprisesTab`
- Définir le code secret

---

## 🆘 Problèmes courants ?

**"npm command not found"**
→ Installer Node.js depuis nodejs.org

**"Fetch error from Supabase"**
→ Vérifier que VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY sont dans .env.local

**"Netlify build fails"**
→ Vérifier que les env vars sont bien ajoutées dans Netlify settings

**"App is slow"**
→ Normal en dev. En prod sur Netlify ça sera ultra rapide !

---

## 💡 Tips

- **Partager l'app** : Une fois sur Netlify, copie le lien et envoie aux amies
- **Backup** : Les données sont sauvegardées sur Supabase (pas de risque de perte)
- **Custom domain** : Tu peux ajouter ton propre domaine sur Netlify
- **Inviter collaborateurs** : Ajoute des devs sur GitHub/Netlify pour modif futures

---

## 🎉 Voilà !

T'as un projet clé-en-main pour un séjour de fou avec les copines !

Questions? Je suis là ! 💙💗

---

**Status**: ✅ Ready to deploy
**Time estimate**: 15-20 minutes
**Difficulty**: Ultra-simple 🎮
