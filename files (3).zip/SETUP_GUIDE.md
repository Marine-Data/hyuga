# 🎮 Guide Setup - Séjour Magique Entre Amies

## 📋 Prérequis
- [ ] Compte Supabase (gratuit sur supabase.com)
- [ ] Compte GitHub
- [ ] Compte Netlify (gratuit)

---

## **ÉTAPE 1️⃣ : SUPABASE - Créer les tables**

### 1. Aller sur https://supabase.com et créer un projet

### 2. Dans Supabase Dashboard → **SQL Editor**, exécuter ce code pour créer les tables :

```sql
-- Table: Activités (Planning)
CREATE TABLE activities (
  id BIGSERIAL PRIMARY KEY,
  day TEXT NOT NULL,
  activity TEXT NOT NULL,
  time TEXT,
  location TEXT,
  meals TEXT,
  checklist TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);

-- Table: Repas
CREATE TABLE meals (
  id BIGSERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  day TEXT,
  responsible TEXT,
  items TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);

-- Table: Liste de courses
CREATE TABLE shopping_list (
  id BIGSERIAL PRIMARY KEY,
  item TEXT NOT NULL,
  done BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Table: Photos (pour Storage)
CREATE TABLE photos (
  id BIGSERIAL PRIMARY KEY,
  filename TEXT NOT NULL,
  storage_path TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Table: Surprises
CREATE TABLE surprises (
  id BIGSERIAL PRIMARY KEY,
  code TEXT NOT NULL,
  content TEXT,
  media_type TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Activer RLS (Row Level Security) - pour les permissions
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE meals ENABLE ROW LEVEL SECURITY;
ALTER TABLE shopping_list ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE surprises ENABLE ROW LEVEL SECURITY;

-- Créer les politiques (tout le monde peut lire/écrire)
CREATE POLICY "Enable read access" ON activities FOR SELECT USING (true);
CREATE POLICY "Enable write access" ON activities FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access" ON activities FOR UPDATE USING (true);

CREATE POLICY "Enable read access" ON meals FOR SELECT USING (true);
CREATE POLICY "Enable write access" ON meals FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read access" ON shopping_list FOR SELECT USING (true);
CREATE POLICY "Enable write access" ON shopping_list FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access" ON shopping_list FOR UPDATE USING (true);

CREATE POLICY "Enable read access" ON photos FOR SELECT USING (true);
CREATE POLICY "Enable write access" ON photos FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read access" ON surprises FOR SELECT USING (true);
CREATE POLICY "Enable write access" ON surprises FOR INSERT WITH CHECK (true);
```

### 3. Copier tes credentials Supabase

Dans **Settings → API** :
- 📋 Copier **Project URL** (ex: `https://xxxx.supabase.co`)
- 📋 Copier **Anon Key** (la clé publique)

---

## **ÉTAPE 2️⃣ : GITHUB - Créer le repo**

### 1. Aller sur https://github.com et créer un **nouveau repo public**

Nom: `sejour-entre-amies`

### 2. Cloner localement

```bash
git clone https://github.com/TON_USERNAME/sejour-entre-amies.git
cd sejour-entre-amies
```

### 3. Créer la structure du projet

```bash
npm create vite@latest . -- --template react
npm install
npm install @supabase/supabase-js
```

### 4. Remplacer `src/App.jsx` avec le code que j'ai créé

Copier-coller le contenu de `sejour-app.jsx` dans `src/App.jsx`

### 5. Créer un fichier `.env.local`

```env
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...ton_key_ici
```

### 6. Modifier `src/App.jsx` pour utiliser les env vars

Remplacer ces lignes :
```javascript
const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_KEY = process.env.REACT_APP_SUPABASE_ANON_KEY || 'your-anon-key';
```

Par :
```javascript
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';
```

### 7. Tester localement

```bash
npm run dev
```

Code: `2024AMIES` pour te login

### 8. Pusher sur GitHub

```bash
git add .
git commit -m "Initial commit: Séjour Magique app"
git push origin main
```

---

## **ÉTAPE 3️⃣ : NETLIFY - Déployer**

### 1. Aller sur https://netlify.com

Cliquer sur **"Connect with GitHub"** → autoriser Netlify

### 2. Cliquer sur **"New site from Git"**

- Choisir ton repo `sejour-entre-amies`

### 3. Configuration du build

Remplir comme ceci :
- **Branch to deploy**: `main`
- **Build command**: `npm run build`
- **Publish directory**: `dist`

### 4. Variables d'environnement

Cliquer sur **"Environment"** et ajouter :
```
VITE_SUPABASE_URL = https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGc...
```

### 5. Cliquer sur **"Deploy"** 🚀

Netlify build automatiquement et deploy ! L'app sera disponible à une URL comme:
```
https://sejour-magique.netlify.app
```

---

## ✨ **C'EST FAIT !**

Ton app est maintenant en ligne ! 

### À customiser:
- [ ] Remplacer le code `2024AMIES` par celui que tu veux
- [ ] Ajouter de vrais repas / activités
- [ ] Ajouter les noms des amies
- [ ] Ajouter la vraie Deezer playlist (elle est déjà là !)
- [ ] Uploader des vraies photos
- [ ] Ajouter tes vidéos secrets

### Magic URLs pour plus tard:
- **App publique**: `https://sejour-magique.netlify.app`
- **Admin Supabase**: `https://app.supabase.com`
- **GitHub repo**: `https://github.com/TON_USERNAME/sejour-entre-amies`

**Questions?** Je suis là pour t'aider ! 💙💗
